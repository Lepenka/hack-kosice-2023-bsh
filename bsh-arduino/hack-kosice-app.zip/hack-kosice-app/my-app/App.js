import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, Pressable } from 'react-native';
import { Gyroscope } from 'expo-sensors';

export default function App() {
  const [gyroscopeData, setGyroscopeData] = useState({ x: 0, y: 0, z: 0 });
  const [textColor, setTextColor] = useState('black');
  const [responseText, setResponseText] = useState('');
  const [shakeMode, setShakeMode] = useState(0);
  const [gyroMode, setGyroMode] = useState(0);
  const [gyroMode2, setGyroMode2] = useState(0);




  const handleButtonClick = () => {
    setShakeMode((shakeMode + 1) % 3);
  };

  const handleButtonClickSmooth = () => {
    fetch('http://10.0.5.96:8000/send-message/2_0/')
        .then((response) => response.json())
        .then((json) => setResponseText(JSON.stringify(json)))
        .catch((error) => console.error(error));
  };

  const handleButtonClickOff = () => {
    fetch('http://10.0.5.96:8000/send-message/0_0/')
        .then((response) => response.json())
        .then((json) => setResponseText(JSON.stringify(json)))
        .catch((error) => console.error(error));
  };

  const handleButtonClickOn = () => {
    fetch('http://10.0.5.96:8000/send-message/10_0/')
        .then((response) => response.json())
        .then((json) => setResponseText(JSON.stringify(json)))
        .catch((error) => console.error(error));
  };
  
  const handleButtonClickLetters = () => {
    fetch('http://10.0.5.96:8000/send-message/3_0/')
        .then((response) => response.json())
        .then((json) => setResponseText(JSON.stringify(json)))
        .catch((error) => console.error(error));
  };

  const handleButtonClickSmooth1 = () => {
    fetch('http://10.0.5.96:8000/send-message/7_0/')
        .then((response) => response.json())
        .then((json) => setResponseText(JSON.stringify(json)))
        .catch((error) => console.error(error));
  };
  
  const handleButtonClickLetters1 = () => {
    fetch('http://10.0.5.96:8000/send-message/8_0/')
        .then((response) => response.json())
        .then((json) => setResponseText(JSON.stringify(json)))
        .catch((error) => console.error(error));
  };

  const handleButtonClickGyro = () => {
    setGyroMode(!gyroMode);
  };

  const handleButtonClickGyro2 = () => {
    setGyroMode2(!gyroMode2);
  };

  useEffect(() => {
    let intervalId = null;
    if (gyroMode) {
      intervalId = setInterval(() => {
        fetch('http://10.0.5.96:8000/gyro/4_' + (gyroscopeData.x * 100).toFixed(0).toString() + '_' + (gyroscopeData.y.toFixed(4) * 100).toFixed(0).toString() + '_' + (gyroscopeData.z * 100).toFixed(0).toString() + '/')
        .then((response) => response.json())
        .then((json) => setResponseText(JSON.stringify(json)))
        .catch((error) => console.error(error));
      }, 50);
    }
    return () => clearInterval(intervalId);
  }, [gyroMode, gyroscopeData]);


  useEffect(() => {
    let intervalId = null;
    if (gyroMode2) {
      intervalId = setInterval(() => {
        fetch('http://10.0.5.96:8000/gyro/5_' + (gyroscopeData.x * 100).toFixed(0).toString() + '_' + (gyroscopeData.y.toFixed(4) * 100).toFixed(0).toString() + '_' + (gyroscopeData.z * 100).toFixed(0).toString() + '/')
        .then((response) => response.json())
        .then((json) => setResponseText(JSON.stringify(json)))
        .catch((error) => console.error(error));
      }, 50);
    }
    return () => clearInterval(intervalId);
  }, [gyroMode2, gyroscopeData]);


  useEffect(() => {
    let subscription = null;
    Gyroscope.isAvailableAsync().then((result) => {
      if (result) {
        subscription = Gyroscope.addListener((data) => {
          setGyroscopeData(data);
          checkForShake(data);
        });
        Gyroscope.setUpdateInterval(50); // in milliseconds

      }
    });
    return () => {
      if (subscription) {
        subscription.remove();
      }
    };
  }, [shakeMode, gyroMode]);

  let lastShakeTime = 0;

  const checkForShake = (data) => {
    const { x, y, z } = data;
    const acceleration = Math.sqrt(x * x + y * y + z * z);
    if (acceleration > 15 && Date.now() - lastShakeTime > 500) { // adjust shake sensitivity and debounce time as needed
      lastShakeTime = Date.now();
      setTextColor('#FF00FF');
      fetch('http://10.0.5.96:8000/send-message/1_' + shakeMode.toString() + '/')
        .then((response) => response.json())
        .then((json) => setResponseText(JSON.stringify(json)))
        .catch((error) => console.error(error));
    }
  }
  

  return (
    <View style={styles.container}>
      <Pressable onPress={handleButtonClickSmooth} style={styles.button}>
        <Text style={styles.buttonText}>Smooth Color Transition</Text>
      </Pressable>
      <Pressable onPress={handleButtonClickLetters} style={styles.button}>
        <Text style={styles.buttonText}>Falling effect</Text>
      </Pressable>
      <Pressable onPress={handleButtonClickSmooth1} style={styles.button}>
        <Text style={styles.buttonText}>Motion Sensor Controlled Animation - Board</Text>
      </Pressable>
      <Pressable onPress={handleButtonClickLetters1} style={styles.button}>
        <Text style={styles.buttonText}>Motion Sensor Controlled Brightness - Board</Text>
      </Pressable>
      <Pressable onPress={handleButtonClickGyro} style={styles.button}>
        <Text style={styles.buttonText}>Motion Sensor Controlled Animation - Phone</Text>
      </Pressable>
      <Pressable onPress={handleButtonClickGyro2} style={styles.button}>
        <Text style={styles.buttonText}>Motion Sensor Controlled Brightness - Phone</Text>
      </Pressable>
      <Pressable onPress={handleButtonClickOn} style={styles.button}>
        <Text style={styles.buttonText}>On</Text>
      </Pressable>
      <Pressable onPress={handleButtonClickOff} style={styles.button}>
        <Text style={styles.buttonText}>Off</Text>
      </Pressable>

      <Text style={[styles.text, { color: textColor }]}>
        Gyroscope Data:
        {'\n'}
        x: {gyroscopeData.x.toFixed(2)}
        {'\n'}
        y: {gyroscopeData.y.toFixed(2)}
        {'\n'}
        z: {gyroscopeData.z.toFixed(2)}
      </Text>


      <Text style={styles.responseText}>{responseText}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'start',
    marginTop: 80,
  },
  text: {
    fontSize: 20,
    textAlign: 'center',
  },
  responseText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
  },
  button: {
    backgroundColor: 'blue',
    width: 320,
    height: 45,
    borderRadius: 5,
    justifyContent: 'center',
    
    marginBottom: 20,
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
  }

});
